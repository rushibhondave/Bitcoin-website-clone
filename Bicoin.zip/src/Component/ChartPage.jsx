import React from 'react'
function ChartPage() {
  return (
    <div>
    <h1>Chrat page</h1>
    </div>
  )
}

export default ChartPage

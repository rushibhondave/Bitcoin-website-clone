import React from "react";

function AlertLine() {
  return (
    <div>
      <div className="News-footer">
        <div className="news">
          <span id="news-head">
            <b>Alerts</b>
          </span>
        </div>
        <p className="N-text">
          <marquee >
            • The developer makes an effort to call an API and requests a moment
            if the duration of the API has reached that limit.
            <span>
              • The developer makes an effort to call an API and requests a
              moment if the duration of the API has reached that limit.
            </span>
            <span>
              • The developer makes an effort to call an API and requests a
              moment if the duration of the API has reached that limit.
            </span>
          </marquee>
        </p>
      </div>
    </div>
  );
}

export default AlertLine;

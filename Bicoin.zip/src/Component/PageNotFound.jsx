import React from 'react'
import error from '../Img/error.jpg'
function PageNotFound() {
  return (
    <div>
      <img src={error} alt="" style={{width:"500px",marginLeft:"35%" ,marginTop:"10%", borderRadius:"20%"}}  srcset="" />
    </div>
  )
}

export default PageNotFound
